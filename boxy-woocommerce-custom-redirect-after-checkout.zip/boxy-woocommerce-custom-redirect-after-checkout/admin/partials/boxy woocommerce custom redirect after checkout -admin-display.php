<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       http://www.9infodev.com/9infotheme/
 * @since      1.0.0
 *
 * @package    Boxy_Woocommerce_Custom_Redirect_After_Checkout
 * @subpackage Boxy_Woocommerce_Custom_Redirect_After_Checkout/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
