=== Boxy woocommerce custom redirect after checkout  ===
Contributors: Mandeep Singh Mann
Tags: wocommerce custom redirect, woocommerce thankyou page, boxy plugins
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

This is a plugin used to redirect user to custom link after successful checkout.
 
== Installation ==

1. Upload `boxy woocommerce custom redirect after checkout .php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to settings and find option name Boxy Wc Redirect.
4. you have done. see result on frontend at time of successfull checkout.

== Upgrade Notice ==

Upgrade normally

== Frequently Asked Questions ==

no questions yet.

== Changelog ==

= 1.0.0 =
* Enjoy the plugin!
